package com.example.calculatorapp.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.calculatorapp.R
import com.example.calculatorapp.databinding.FragmentCalCulatorBinding
import com.example.calculatorapp.viewmodel.CalculatorViewModel


class Calculator : Fragment() {

    lateinit var binding:FragmentCalCulatorBinding
    lateinit var  viewModel: CalculatorViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_cal_culator,container,false)
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)
        binding.viewModel = viewModel

        return binding.root
    }



}


