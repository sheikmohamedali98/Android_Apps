package com.example.calculatorapp.viewmodel


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import org.mariuszgromada.math.mxparser.Expression

class CalculatorViewModel : ViewModel() {


    private val _display = MutableLiveData<String>()
    val display: LiveData<String>
        get() = _display

    private val _result = MutableLiveData<String>()
    val result: LiveData<String>
        get() = _result


    init {
        _display.value = ""
        _result.value = ""

    }

    fun clearScreen() {
        _display.value = ""
        _result.value = ""

    }

    fun calcelLast() {
        val length = _display.value?.length
        if (length != null) {
            _display.value = _display.value?.substring(0, length.minus(1))
        }
    }



    fun operation(){
        var value = _display.value
        var result = "0"
        if (value != null) {
            value = value.replace("÷","/")
            value = value.replace("×","*")
            val exp = Expression(value)
             result = exp.toString()

        }
        _result.value = result
    }

    fun appendOperation(ch: Char,canAdd:Boolean) {
        var word = ch.toString()
       if(canAdd){
           _result.value = ""
           _display.value += word
       }else{
           _display.value += _result.value
           _display.value += word
           _result.value = ""
       }
    }

    fun dotExpression(){
        if(_display.value?.isEmpty() == true){
            return
        }
        if(_display.value?.last()?.isDigit() != true){
            return
        }
         appendOperation('.',true)
    }

//    fun addDotToExpression() {
//        if(expression.value!!.isEmpty()) return
//        if(!expression.value!!.last().isDigit()) return
//        addToExpression(".")
//    }

//    binding.cBtn.setOnClickListener {
//            var number = showText.text.toString()
//            if (number.isNotEmpty()) {
//                showText.text = number.substring(0, number.length - 1)
//            } else {
//                showText.text = ""
//            }
//        }

//    private fun validateTheNumber(numberString: String) {
//        var tempString = ""
//        var currentChar = ' '
//        var tempChar = ' '
//        var result = 0
//        for (position in 0 until numberString.length) {
//            if (numberString[position] == '+' || numberString[position] == '-' || numberString[position] == '*' || numberString[position] == '/' ) {
//                if (numberString[position] != '=') {
//                    tempChar = numberString[position]
//                }
//                if (_result.value?.isEmpty() == true) {
//                    result = tempString.toInt()
//                    _result.value = result.toString()
//                    currentChar = numberString[position]
//                    tempString = ""
//                } else if (currentChar == '+' || currentChar == '-' || currentChar == '*' || currentChar == '/') {
//                    _display.value = CalculatingValues
//                        .operationPerformedBy(_result.value?.toInt()!!,
//                            currentChar,
//                            tempString).toString()
//                    currentChar = tempChar
//                    tempString = ""
//                }
//                } else if (numberString[position].code >= 48 && numberString[position].code <= 57) {
//                    tempString += numberString[position]
//                } else {
////                    Toast.makeText(this@CalculatorViewModel, "Invalid INPUT ", Toast.LENGTH_SHORT)
//                    break
//                }
//            }
//        }
    }
