package com.example.newsapp.domain


data class NewsResponse(
    var category: String,
    var data: List<Data>,
    var success: Boolean
)