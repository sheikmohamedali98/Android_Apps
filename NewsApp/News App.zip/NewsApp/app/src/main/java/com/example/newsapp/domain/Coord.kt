package com.example.newsapp.domain

data class Coord(
    val lat: Int,
    val lon: Int
)