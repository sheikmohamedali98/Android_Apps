package com.example.newsapp.database

import androidx.room.Dao
import androidx.room.Insert

@Dao
interface DataDao {

//    @Insert()
//    suspend fun insert(Vi)

}