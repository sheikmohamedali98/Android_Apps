package com.example.newsapp.domain

data class Wind(
    val deg: Int,
    val speed: Double
)