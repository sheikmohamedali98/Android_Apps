package com.example.newsapp.viewmodel

import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsapp.domain.Data
import com.example.newsapp.domain.NewsResponse
import com.example.newsapp.api.NewsApi
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import retrofit2.Response

class HomeViewModel:ViewModel() {

    private val _newsProperties = MutableLiveData<List<Data>?>()

    val newsProperties: MutableLiveData<List<Data>?>
    get() = _newsProperties



    init {

        getNewsProperties()
    }

    private fun getNewsProperties() {
        viewModelScope.launch() {
            val getNewsResponse = NewsApi.retrofitService.getAllNews()
            if(getNewsResponse.isSuccessful){
                val item =  getNewsResponse.body()?.data
               _newsProperties.value = item
                println("\n\n\n\n\n${_newsProperties.value}\n\n\n\n\n")
            }else{

            }

        }
    }
}