package com.example.newsapp.domain

data class Clouds(
    val all: Int
)